 <!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>About Us</title>
        <link rel="stylesheet" type="text/css" href="Styles/StyleSheet.css"/>
        <Style>
        
html{box-sizing:border-box}*,*:before,*:after{box-sizing:inherit}
/* Extract from normalize.css by Nicolas Gallagher and Jonathan Neal git.io/normalize */
html{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}
body{margin:0
}
body {
  background-color: white;
  color: #222;
  font-family: "HelveticaNeue-Light", "Helvetica Neue Light", "Helvetica Neue", Helvetica, Arial, "Lucida Grande", sans-serif;
  font-weight: 400;
  font-size: 25px;
}

nav {
  background-color: chocolate;
  border: 1px solid #dedede;
  border-radius: 4px;
  box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.055);
  color: #888;
  display: block;
  margin: 5px 22px 5px 22px;
  overflow: hidden;
  width: 96%; 
}

  nav ul {
    margin: 0;
    padding: 0;
  }

    nav ul li {
      display: inline-block;
      list-style-type: none;
      
      -webkit-transition: all 0.2s;
        -moz-transition: all 0.2s;
        -ms-transition: all 0.2s;
        -o-transition: all 0.2s;
        transition: all 0.2s; 
    }
      
      nav > ul > li > a > .caret {
        border-top: 4px solid #aaa;
        border-right: 4px solid transparent;
        border-left: 4px solid transparent;
        content: "";
        display: inline-block;
        height: 0;
        width: 0;
        vertical-align: middle;
  
        -webkit-transition: color 0.1s linear;
          -moz-transition: color 0.1s linear;
        -o-transition: color 0.1s linear;
          transition: color 0.1s linear; 
      }

      nav > ul > li > a {
        color: #aaa;
        display: block;
        line-height: 56px;
        padding: 0 24px;
        text-decoration: none;
      }

        nav > ul > li:hover {
          background-color: rgb( 40, 44, 47 );
        }

        nav > ul > li:hover > a {
          color: rgb( 255, 255, 255 );
        }

        nav > ul > li:hover > a > .caret {
          border-top-color: rgb( 255, 255, 255 );
        }
      
      nav > ul > li > div {
        background-color: rgb( 40, 44, 47 );
        border-top: 0;
        border-radius: 0 0 4px 4px;
        box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.055);
        display: none;
        margin: 0;
        opacity: 0;
        position: absolute;
        width: 165px;
        visibility: hidden;
  
        -webkit-transiton: opacity 0.2s;
        -moz-transition: opacity 0.2s;
        -ms-transition: opacity 0.2s;
        -o-transition: opacity 0.2s;
        -transition: opacity 0.2s;
      }

        nav > ul > li:hover > div {
          display: block;
          opacity: 1;
          visibility: visible;
        }

          nav > ul > li > div ul > li {
            display: block;
          }

            nav > ul > li > div ul > li > a {
              color: #fff;
              display: block;
              padding: 12px 24px;
              text-decoration: none;
            }

              nav > ul > li > div ul > li:hover > a {
                background-color: rgba( 255, 255, 255, 0.1);
              }
  
 body{
    font-family: lucinda grande, tahoma,arial,sans-serif;
     color: black;
   background-image:url(../Images/bg.jpg);
}

body p{
    font-size: 0.8;
    line-height: 1.28;
}

#wrapper{
    background-image:url(../Images/bg.jpg);
    width: 1080px;
    background-color: chocolate;
    margin: 0 auto;
    padding: 10px;
    border: 15px solid #dedede;
}
 

#banner{
    
    
    background-repeat: no-repeat;
    background-size:cover;
    border: 5px solid #dedede;
    height: 200px;
    
}
#content_area{
    float: left;
    width: 750px;
    margin: 20px 0 20px 0;
    padding: 10px;
}
#top-nav { margin:0 auto; padding:0px 0 0; height:37px; float:right;}
			#top-nav ul { list-style:none; padding:0; height:37px; float:left;}
			#top-nav ul li { margin:0; padding:0 0 0 8px; float:left;}
			#top-nav ul li a { display:block; margin:0; padding:8px 20px; color:red; text-decoration:none;}
			#top-nav ul li.active a, #top-nav ul li a:hover { color:#f8dbdb;}
#sidebar{
    float: right;
    width: 250px;
    height: 400px;
    margin: 20px 0 10px 0;
    padding: 10px;
    border: 2px solid #E3E3E3;
    
}
#footer{
    clear: both;
    width: auto;
    height: 40px;
    padding: 10px;
    border: 3px solid #E3E3E3;
    text-align: center;
    color:#fff;
    text-shadow:0.1em 0.1em #333;
    background-image: url(../Images/bg.jpg);
}

 
     .navbar{
		margin-top: 20px;
	}

#nav{
    list-style: none;
}
#nav ul{
    margin: 0;
    padding:0;
    width:auto;
    display: none;
}
#nav li{
    font-size: 24px;
    float:left;
    position:relative;
    width: 180px;
    height: 50px;
}
#nav a:link, nav a:active, nav a:visited{
    display:block;
    color: #fff;
    text-decoration:none;
}
#nav a:hover{
    color: black;
}
.feature { background:black;padding:12px;}
.feature-inner { margin:auto;width:470px; }
.feature-inner h1 {color:orange;font-size:55px;}

</Style>

    </head>
     <div id="banner">
         <div class="feature-inner">
				<h1>About Us</h1>
				</div>
        </div>
    
    <body>
       
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        
        
        <div id="wrapper">
             
            
            
            <nav id="navigation">
              
            </nav>
 <p> ELS Event Supply CC is a company that deals with events. 
     They hire out and sell Tents, chairs, tables, table 
     cloths, carpets, stages and wedding gowns. 
    <p></p> 
 They operate their business in Namibia only. 
 Any customer that need to book any of the mentioned above products 
 they need to visit their website for detailed information. 
The reason why they decided to change their booking pattern from manual
to web based system is because it helps them to manage the customers
booking easily and it is also reliable. This will also help the 
administrators to keep track of their customer’s online booking request 
and be able to give a quick feedback to their customer’s request. 
<p></p>
We chose this client because we feel like the website would be a great
platform to exhibit her products and also extend the business exposure 
to all the potential customers. Through this she is also able to reach 
out to as many clients as possible, as the website would be 
accessible from anywhere around the country.</p>

                
                
    </div> 
         <nav>
    <ul>
        <li><a href="home.php">Home</a></li>
        <li>
      <a href="home.php">Categories <span class="caret"></span></a>
            <div>
                <ul>
                  <li><a href="Events.php">Decor</a></li>
                    <li><a href="weddings.php">Wedding Dresses</a></li>
                    
                </ul>   
            </div>
        <li><a href="About Us.php">About Us</a></li>
        <li><a href="Contact Us.php">Contact Us</a></li>
    </ul>
</nav>
          
            <div id="content_area">
                <!--<?php echo $content; ?>-->
        <footer>
            
            <div class="container">
            <div class="text-center">
                
                <hr>
                <p>Copyright © 2017 ELS Events. All Rights Reserved</p>
                <hr>
                <!--Copyright-->
                <p>Website by <a href="Alpha.php" target="_blank" style="color: whitesmoke;">Alpha</a>.</p>
            </div>
        </div>
            
        </footer>
        </div>
        
    </body>
      
</html>

			 