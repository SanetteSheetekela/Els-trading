 <?php
 $title="Home";
 $content="Welcome to ELS shop. Here we Hire Tents, Chairs, Tables,Carpets,
          Stages, Decor, Catering, Wedding Gowns & Suits,
         Bridesmaid Dresses, call or email us to get quotation.";
 
 include'Home.php';
 ?>
 