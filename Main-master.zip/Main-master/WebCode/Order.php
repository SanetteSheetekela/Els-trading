<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title> </title>
    </head>
    <body>
        
        
                 
        <?php
        echo 'Thanks for shopping with us!!!!Your order has been approved. Your order number has been sent to your email address.';
        ?>
        <p> <a href="Home.php" target="_blank" style="color: #333;">Go back home</a>.</p>
    </body>
</html>
