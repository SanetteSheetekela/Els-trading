#ELS event supply is a company that deals with events. They hire out and sells tents, chairs and wedding gowns!
